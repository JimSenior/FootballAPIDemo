﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FootballAPIDemo.Model
{
    public static class TeamList
    {
        public static List<string> TeamNames = new List<string>();

    }
}